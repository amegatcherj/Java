package com.CocktailRetailShop;

import java.util.Scanner;


public class PricesBGroup5 {

    Scanner AcceptItemPrice = new Scanner(System.in);
    
    static double PriceForFirstItem;
    static double PriceForSecondItem;
    static double PriceForThirdItem;
    static double PriceForFourthItem;
    static double PriceForFifthItem;







    public void GetAndSetUnitPrice(){

        String FirstItem = ItemsBGroup5.Items[0];
        String SecondItem = ItemsBGroup5.Items[1];
        String ThirdItem = ItemsBGroup5.Items[2];
        String FourthItem = ItemsBGroup5.Items[3];
        String FifthItem = ItemsBGroup5.Items[4];


        System.out.print("What is the Price of " + FirstItem + " : ");
        PriceForFirstItem = AcceptItemPrice.nextDouble();

        System.out.print("What is the Price of " + SecondItem + " : ");
        PriceForSecondItem = AcceptItemPrice.nextDouble();

        System.out.print("What is the Price of " + ThirdItem + " : ");
        PriceForThirdItem = AcceptItemPrice.nextDouble();

        System.out.print("What is the Price of " + FourthItem + " : ");
        PriceForFourthItem = AcceptItemPrice.nextDouble();

        System.out.print("What is the Price of " + FifthItem + " : ");
        PriceForFifthItem = AcceptItemPrice.nextDouble();






    }

}
