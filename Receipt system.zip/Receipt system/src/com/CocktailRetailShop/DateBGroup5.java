package com.CocktailRetailShop;

import java.util.Scanner;

public class DateBGroup5 {

    static String orderMonth;
    static String orderDay;
    static String orderYear;

    Scanner AcceptDate = new Scanner(System.in);

    public void GetAndSetDate(){

        System.out.println("Enter details of client's visit below");
        System.out.println("*******************************************");

        System.out.print("Enter month-number: ");
        orderMonth = AcceptDate.next();

        System.out.print("Enter day-number: ");
        orderDay = AcceptDate.next();

        System.out.print("Enter year: " );
        orderYear = AcceptDate.next();


    }

}
