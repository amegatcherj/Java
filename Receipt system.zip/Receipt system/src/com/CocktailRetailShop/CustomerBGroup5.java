package com.CocktailRetailShop;

import java.util.Scanner;

public class CustomerBGroup5 {

     Scanner AcceptCustomerInput = new Scanner(System.in);

     String welcomeMSG = "Welcome to Koans Pharmacy";

     static String customerName;
     static String customerMobileNumber;


     public void SetCustomerDetails(){

         System.out.println(welcomeMSG);

         System.out.print("Please enter customer's name: ");
         customerName = AcceptCustomerInput.next();

         System.out.print("Please enter customer's mobile phone number: ");
         customerMobileNumber = AcceptCustomerInput.next();






     }









}
