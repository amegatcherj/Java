package com.CocktailRetailShop;

import java.util.Scanner;

public class ItemsBGroup5 {

    // Items names  in array
    static String[] Items = new String[5];

    // Item quantities
    static int quantityForFirstItem;
    static int quantityForSecondItem;
    static int quantityForThirdItem;
    static int quantityForFourthItem;
    static int quantityForFifthItem;








    static public void GetAndSetItems(){

        Scanner AcceptItems = new Scanner(System.in);

        // Get Item Names
        System.out.print("Please enter first item: ");
        Items[0] = AcceptItems.next();

        System.out.print("Please enter second item: ");
        Items[1] = AcceptItems.next();

        System.out.print("Please enter third item: ");
        Items[2] = AcceptItems.next();

        System.out.print("Please enter fourth item: ");
        Items[3] = AcceptItems.next();

        System.out.print("Please enter fifth item: ");
        Items[4] = AcceptItems.next();

        // Get Item quantities
        System.out.print("How many " + Items[0] + " were ordered: ");
        quantityForFirstItem = AcceptItems.nextInt();

        System.out.print("How many " + Items[1] + " were ordered: ");
        quantityForSecondItem = AcceptItems.nextInt();

        System.out.print("How many " + Items[2] + " were ordered: ");
        quantityForThirdItem = AcceptItems.nextInt();

        System.out.print("How many " + Items[3] + " were ordered: ");
        quantityForFourthItem = AcceptItems.nextInt();

        System.out.print("How many " + Items[4] + " were ordered: ");
        quantityForFifthItem = AcceptItems.nextInt();









    }

}
