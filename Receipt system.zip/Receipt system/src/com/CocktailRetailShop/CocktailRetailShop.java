package com.CocktailRetailShop;



public class CocktailRetailShop {



    static public void createReceipt(int totalNumberOfItems, double TotalOrder, double totalDiscount){

        System.out.println("-/- Koans Pharmacy -/-\n");
        System.out.println("===================================");
        System.out.println("Customer: " + CustomerBGroup5.customerName);
        System.out.println("Mobile Phone: " + CustomerBGroup5.customerMobileNumber);
        System.out.println("Order Date: " + DateBGroup5.orderDay + "/" + DateBGroup5.orderMonth + "/" +  DateBGroup5.orderYear);
        System.out.println("---------------------------------------------------");
        System.out.println("Item Type\t\tQty\t\tUnitPrice\t\tSub-Total");
        System.out.println("---------------------------------------------------");

        System.out.print(

                ItemsBGroup5.Items[0] + "\t\t\t\t" + ItemsBGroup5.quantityForFirstItem + "\t\t$" + PricesBGroup5.PriceForFirstItem + "\t\t\t$" + (ItemsBGroup5.quantityForFirstItem * PricesBGroup5.PriceForFirstItem) + "\n" +
                ItemsBGroup5.Items[1] + "\t\t\t\t" + ItemsBGroup5.quantityForSecondItem + "\t\t$" + PricesBGroup5.PriceForSecondItem + "\t\t\t$" + (ItemsBGroup5.quantityForSecondItem * PricesBGroup5.PriceForSecondItem) + "\n" +
                ItemsBGroup5.Items[2] + "\t\t\t\t" + ItemsBGroup5.quantityForThirdItem + "\t\t$" + PricesBGroup5.PriceForThirdItem + "\t\t\t$" + (ItemsBGroup5.quantityForThirdItem * PricesBGroup5.PriceForThirdItem) + "\n" +
                ItemsBGroup5.Items[3] + "\t\t\t\t" + ItemsBGroup5.quantityForFourthItem  + "\t\t$" + PricesBGroup5.PriceForFourthItem + "\t\t\t$" + (ItemsBGroup5.quantityForFourthItem * PricesBGroup5.PriceForFourthItem) + "\n" +
                ItemsBGroup5.Items[4] + "\t\t\t\t" + ItemsBGroup5.quantityForFifthItem + "\t\t$" + PricesBGroup5.PriceForFifthItem + "\t\t\t$" + (ItemsBGroup5.quantityForFifthItem * PricesBGroup5.PriceForFifthItem) + "\n"

        );
        System.out.println("---------------------------------------");
        System.out.println("Number of Items: " + totalNumberOfItems);
        System.out.println("Total Order: $" + TotalOrder + " Total Discount: $" + totalDiscount);
        System.out.println("==========================================================");
        System.out.println("Created by BGroup, Index Numbers");





    }

    // Instance of CustomerBGroup5
    static CustomerBGroup5 CUSTOMER_DETALS  = new CustomerBGroup5();

    // Instance of ItemsBGroup5
    static ItemsBGroup5 COLLECT_ITEMS = new ItemsBGroup5();

    // Instance of PricesBGroup5
    static PricesBGroup5 ITEM_PRICES = new PricesBGroup5();

    static DateBGroup5 GET_DATE = new DateBGroup5();









    public static void main(String[] args) {


        // Get and set customer details
        CUSTOMER_DETALS.SetCustomerDetails();

        // Get and set Items from customer
        COLLECT_ITEMS.GetAndSetItems();

        // Collect Item Prices from user
        ITEM_PRICES.GetAndSetUnitPrice();

        // Get customer visit date
        GET_DATE.GetAndSetDate();

        int totalNumberOfItems =    ItemsBGroup5.quantityForFirstItem +
                                    ItemsBGroup5.quantityForSecondItem +
                                    ItemsBGroup5.quantityForThirdItem +
                                    ItemsBGroup5.quantityForFourthItem +
                                    ItemsBGroup5.quantityForFifthItem;


        double TotalOrder = (ItemsBGroup5.quantityForFirstItem * PricesBGroup5.PriceForFirstItem) +
                            (ItemsBGroup5.quantityForSecondItem * PricesBGroup5.PriceForSecondItem) +
                            (ItemsBGroup5.quantityForThirdItem * PricesBGroup5.PriceForThirdItem) +
                            (ItemsBGroup5.quantityForFourthItem * PricesBGroup5.PriceForFourthItem) +
                            (ItemsBGroup5.quantityForFifthItem * PricesBGroup5.PriceForFifthItem);


        double totalDiscount = TotalOrder * 0.25;


        createReceipt(totalNumberOfItems,TotalOrder,totalDiscount);


    }
}
